# Book Inventory (iOS, Python)

Take a photo of a bookshelf; the app reads the spines and adds the books to a local inventory.

Built with [BeeWare](https://beeware.org) (Toga + Briefcase), so the app is written in Python and packaged as a native iOS app.

## How it works

1. `app.py` – Toga UI. Opens the camera (`toga.App.camera.take_photo()`), shows the inventory table.
2. `ocr.py` – Apple's Vision framework (via Rubicon-ObjC) reads text on-device. The photo is scanned upright and rotated both ways, since spine text is vertical.
3. `matching.py` – drops noisy OCR lines and scores search results against the OCR text.
4. `lookup.py` – looks up each line on the free [Open Library](https://openlibrary.org/dev/docs/api/search) API and keeps results that match.
5. `database.py` – stores books in SQLite on the device (duplicates ignored).

## Requirements

- macOS with **full Xcode** installed (the Command Line Tools alone are not enough)
- Python 3.10+

## Run

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install briefcase pytest

pytest                       # unit tests for the platform-independent logic
briefcase create iOS
briefcase build iOS
briefcase run iOS            # launches in the iOS Simulator
```

The Simulator has no real camera. `take_photo()` falls back to a photo-library picker there. To use the camera, run on a device (`briefcase run iOS -d`, requires an Apple developer team).

## Notes and limitations

- Not run on iOS in this environment (no Xcode and no package-index access), so `app.py` and `ocr.py` are untested. The logic in `matching.py`, `lookup.py`, `scanner.py` and `database.py` is covered by `tests/test_core.py`.
- The Vision calls in `ocr.py` use Rubicon-ObjC keyword-argument syntax. If a call fails on first run, that file is the first place to check.
- Recognition quality depends on photo quality: take close, well-lit shots of one or two shelf rows at a time. Spines with stylized fonts may not be recognized.
- Lookups need an internet connection; OCR does not.
- Edit `bundle` and `author` in `pyproject.toml` before building.
