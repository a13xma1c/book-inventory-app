"""Book metadata lookup using the free Open Library search API (no API key)."""

import json
import urllib.parse
import urllib.request

from bookinventory.database import Book
from bookinventory.matching import is_match

SEARCH_URL = "https://openlibrary.org/search.json"
FIELDS = "title,author_name,first_publish_year,isbn"


def _fetch(query: str, timeout: float = 10.0) -> dict:
    params = urllib.parse.urlencode({"q": query, "limit": 3, "fields": FIELDS})
    request = urllib.request.Request(
        f"{SEARCH_URL}?{params}", headers={"User-Agent": "BookInventoryApp/0.1"}
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def find_book(query: str, fetch=_fetch) -> Book | None:
    """Return the first search result that plausibly matches the OCR text."""
    try:
        data = fetch(query)
    except OSError:  # network down, timeout, HTTP error
        return None
    for doc in data.get("docs", []):
        title = doc.get("title", "")
        authors = ", ".join(doc.get("author_name", [])[:2])
        if title and is_match(query, title, authors):
            isbns = doc.get("isbn") or [""]
            return Book(
                title=title,
                authors=authors,
                year=str(doc.get("first_publish_year", "")),
                isbn=isbns[0],
            )
    return None
