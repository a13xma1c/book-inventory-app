"""On-device text recognition using Apple's Vision framework (iOS only).

Book spines are usually printed sideways, so the photo is analysed three times:
upright, rotated clockwise and rotated counter-clockwise. Vision runs entirely
on the device; no image leaves the phone.
"""

import ctypes

# CGImagePropertyOrientation values
_ORIENTATIONS = (1, 6, 8)  # up, right, left
_VISION_PATH = "/System/Library/Frameworks/Vision.framework/Vision"
_RECOGNITION_LEVEL_ACCURATE = 0


def recognize_text(image_bytes: bytes) -> list[str]:
    """Return every line of text Vision finds in the encoded image (PNG/JPEG)."""
    from rubicon.objc import ObjCClass

    ctypes.CDLL(_VISION_PATH)
    NSData = ObjCClass("NSData")
    UIImage = ObjCClass("UIImage")
    VNImageRequestHandler = ObjCClass("VNImageRequestHandler")
    VNRecognizeTextRequest = ObjCClass("VNRecognizeTextRequest")

    ns_data = NSData.dataWithBytes(image_bytes, length=len(image_bytes))
    cg_image = UIImage.imageWithData(ns_data).CGImage

    lines: list[str] = []
    for orientation in _ORIENTATIONS:
        request = VNRecognizeTextRequest.alloc().init()
        request.recognitionLevel = _RECOGNITION_LEVEL_ACCURATE
        request.usesLanguageCorrection = True
        handler = VNImageRequestHandler.alloc().initWithCGImage(
            cg_image, orientation=orientation, options=None
        )
        handler.performRequests([request], error=None)
        for observation in request.results or []:
            candidates = observation.topCandidates(1)
            if candidates:
                lines.append(str(candidates[0].string))
    return lines
