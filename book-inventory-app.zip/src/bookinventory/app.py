"""Book Inventory: photograph a bookshelf and list the books on it."""

import asyncio

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW

from bookinventory.database import Database
from bookinventory.ocr import recognize_text
from bookinventory.scanner import identify_books


class BookInventory(toga.App):
    def startup(self):
        self.paths.data.mkdir(parents=True, exist_ok=True)
        self.db = Database(str(self.paths.data / "books.sqlite3"))

        self.status = toga.Label("Take a photo of a bookshelf to begin.", style=Pack(margin=5))
        self.table = toga.Table(
            headings=["Title", "Author", "Year"],
            accessors=["title", "authors", "year"],
            style=Pack(flex=1),
        )
        scan_button = toga.Button(
            "Scan Bookshelf", on_press=self.scan_shelf, style=Pack(flex=1, margin=5)
        )
        delete_button = toga.Button(
            "Delete Selected", on_press=self.delete_selected, style=Pack(flex=1, margin=5)
        )

        self.main_window = toga.MainWindow(title=self.formal_name)
        self.main_window.content = toga.Box(
            children=[
                self.status,
                self.table,
                toga.Box(children=[scan_button, delete_button], style=Pack(direction=ROW)),
            ],
            style=Pack(direction=COLUMN, margin=10),
        )
        self.refresh()
        self.main_window.show()

    def refresh(self):
        books = self.db.all()
        self.table.data = [
            {"title": b.title, "authors": b.authors, "year": b.year, "id": b.id} for b in books
        ]

    async def scan_shelf(self, widget, **kwargs):
        try:
            photo = await self.camera.take_photo()
        except PermissionError:
            self.status.text = "Camera access denied. Enable it in Settings > Book Inventory."
            return
        if photo is None:
            return  # user cancelled

        self.status.text = "Reading spines..."
        try:
            # Vision and the network lookups block, so keep them off the UI thread.
            lines = await asyncio.to_thread(recognize_text, photo.data)
            books = await asyncio.to_thread(identify_books, lines)
        except Exception as exc:
            self.status.text = f"Scan failed: {exc}"
            return

        added = sum(self.db.add(book) for book in books)
        self.refresh()
        self.status.text = (
            f"Found {len(books)} book(s), {added} new. Inventory total: {self.db.count()}."
        )

    def delete_selected(self, widget, **kwargs):
        row = self.table.selection
        if row is None:
            self.status.text = "Select a book to delete."
            return
        self.db.delete(row.id)
        self.refresh()
        self.status.text = f"Inventory total: {self.db.count()}."


def main():
    return BookInventory()
