"""Turn raw OCR text into book-search queries and verify search results."""

import re

_TOKEN = re.compile(r"[a-z0-9]+")
_STOPWORDS = {"the", "a", "an", "of", "and", "in", "to", "by"}

MIN_QUERY_LENGTH = 4
MIN_MATCH_SCORE = 0.6


def tokens(text: str) -> list[str]:
    return [t for t in _TOKEN.findall(text.lower()) if t not in _STOPWORDS]


def candidate_queries(lines: list[str]) -> list[str]:
    """Filter and de-duplicate OCR lines that could plausibly be book text."""
    seen: set[str] = set()
    result: list[str] = []
    for line in lines:
        line = " ".join(line.split())
        letters = sum(c.isalpha() for c in line)
        if len(line) < MIN_QUERY_LENGTH or letters < MIN_QUERY_LENGTH:
            continue
        if letters / len(line) < 0.6:  # mostly digits/punctuation: noise
            continue
        key = line.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(line)
    return result


def match_score(ocr_text: str, title: str, authors: str) -> float:
    """Fraction of OCR tokens that appear in the result's title or authors."""
    wanted = tokens(ocr_text)
    if not wanted:
        return 0.0
    available = set(tokens(title)) | set(tokens(authors))
    return sum(t in available for t in wanted) / len(wanted)


def is_match(ocr_text: str, title: str, authors: str) -> bool:
    return match_score(ocr_text, title, authors) >= MIN_MATCH_SCORE
