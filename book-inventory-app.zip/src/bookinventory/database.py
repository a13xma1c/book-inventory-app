"""SQLite storage for the book inventory."""

import sqlite3
from dataclasses import dataclass


@dataclass
class Book:
    title: str
    authors: str = ""
    year: str = ""
    isbn: str = ""
    id: int | None = None


class Database:
    def __init__(self, path: str = ":memory:"):
        self._conn = sqlite3.connect(path)
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                authors TEXT NOT NULL DEFAULT '',
                year TEXT NOT NULL DEFAULT '',
                isbn TEXT NOT NULL DEFAULT '',
                added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (title COLLATE NOCASE, authors COLLATE NOCASE)
            )
            """
        )
        self._conn.commit()

    def add(self, book: Book) -> bool:
        """Insert a book. Returns False if it is already in the inventory."""
        cur = self._conn.execute(
            "INSERT OR IGNORE INTO books (title, authors, year, isbn) VALUES (?, ?, ?, ?)",
            (book.title, book.authors, book.year, book.isbn),
        )
        self._conn.commit()
        return cur.rowcount == 1

    def all(self) -> list[Book]:
        rows = self._conn.execute(
            "SELECT id, title, authors, year, isbn FROM books ORDER BY title COLLATE NOCASE"
        )
        return [Book(id=r[0], title=r[1], authors=r[2], year=r[3], isbn=r[4]) for r in rows]

    def delete(self, book_id: int) -> None:
        self._conn.execute("DELETE FROM books WHERE id = ?", (book_id,))
        self._conn.commit()

    def count(self) -> int:
        return self._conn.execute("SELECT COUNT(*) FROM books").fetchone()[0]

    def close(self) -> None:
        self._conn.close()
