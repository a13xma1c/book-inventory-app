"""Photo -> list of identified books."""

from bookinventory.database import Book
from bookinventory.lookup import find_book
from bookinventory.matching import candidate_queries


def identify_books(lines: list[str], find=find_book) -> list[Book]:
    """Look up each plausible OCR line and return the distinct books found."""
    books: dict[tuple[str, str], Book] = {}
    for query in candidate_queries(lines):
        book = find(query)
        if book:
            books.setdefault((book.title.lower(), book.authors.lower()), book)
    return list(books.values())
